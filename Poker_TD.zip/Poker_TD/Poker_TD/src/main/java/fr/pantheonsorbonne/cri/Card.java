package fr.pantheonsorbonne.cri;

public class Card {
    
    int suite;
    int value;
   

    public Card(int s, int v){
        this.suite=s;
        this.value=v;
    }


   
}
