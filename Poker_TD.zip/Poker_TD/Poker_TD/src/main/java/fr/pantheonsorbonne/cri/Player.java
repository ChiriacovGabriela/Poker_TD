package fr.pantheonsorbonne.cri;
import java.util.Scanner;
import java.util.ArrayList;

public class Player {
    static Scanner sc=new Scanner(System.in);
    private String name;

    public Player( String unNom){
        this.name=unNom;
    }
    public static   Card[] hand;
    
    public void setHand(Card[] carte){
        for(int i=0;i<carte.length;i++){
            this.hand[i]=carte[i];
        }
    }

    public void addCard(Card[] carte){
        for(int i=0;i<carte.length;i++){
            if(hand[i]==null){
                this.hand[i]=carte[i];
            }
        }
    }

    public Card[] getCardsToDiscard(){
        for(int i=0;i<5;i++){
            System.out.println((this.hand[i]));
        }
        System.out.println("cartes echanger");
        int ech=sc.nextInt();
        Card[] discard=new Card[ech];
        for(int i=0;i<ech;i++){
            System.out.println("position carte echange ");
            int num=sc.nextInt();
            for(int j=0;j<this.hand.length;j++){
                if(j+i==num){
                    discard[i]=hand[j];
                }
            }
        }
        return discard;
    }

    public static int jeux(Card[] cards){
        int countMax=1;
        for(int i=0;i<cards.length;i++){
            int count=1;
            for(int j=i+1;j<cards.length;j++){
                if(cards[i].equals(cards[j])){
                    count++;
                }
            }
            if(count>countMax){
                countMax=count;
            }
        }
        if(countMax==4)
            return 4;
        if(countMax==3)
            return 3;
        if(countMax==2)
            return 2;
        else
            return 0;
    }

    public boolean beats(Player joueur){
        if(Player.jeux(this.hand)>Player.jeux(joueur.hand)){
            return true;
        }else{
            return false;
        }
    }

    public void getHandString(){
        for(int i=0;i<5;i++){
            System.out.println(this.hand[i]);
        }

    }

    public static void main(String[] args ){
    
   
    }
}
